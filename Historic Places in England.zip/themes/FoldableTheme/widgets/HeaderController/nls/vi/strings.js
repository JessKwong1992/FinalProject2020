define({
  "_widgetLabel": "Trình điều khiển Đầu trang",
  "signin": "Đăng nhập",
  "signout": "Đăng xuất",
  "about": "Về",
  "signInTo": "Đăng nhập vào",
  "cantSignOutTip": "Chức năng này không khả dụng trong chế độ xem trước.",
  "more": "khác"
});